var img_width = "468";
var img_height = "60";
var img_title = "Just Click Here you can be a winner";

var ad=new Array()

ad[0]='http://i24.ir/ads/tablighat.gif';
ad[1]='images/23m8rpf.gif';
ad[2]='images/2euu7th.gif';





var links=new Array() 

links[0]='http://myi24.com';
links[1]='http://myi24.com';
links[2]='http://myi24.com';





var xy=Math.floor(Math.random()*ad.length);
document.write('<a href="'+links[xy]+'" target="_blank"><img src="'+ad[xy]+'" width="'+img_width+'" height="'+img_height+'" alt="'+img_title+'" border="0"></a>');